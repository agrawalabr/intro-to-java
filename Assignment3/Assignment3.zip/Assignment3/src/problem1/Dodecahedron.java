package problem1;

public class Dodecahedron {

	public static void main(String[] args) {
		
	}
}
