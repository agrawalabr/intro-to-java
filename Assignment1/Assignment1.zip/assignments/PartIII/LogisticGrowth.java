public class LogisticGrowth {

	public static double calculatePopulation(double p, double k, double r, int t) {
		return k/(1 + ((k - p) / p) * Math.exp(-r * t));
	}
	
	
	public static void main(String[] args) {
		
		double p = 100;
		double k = 10000;
		double r = 3e-1;
		int[] time = {0, 10, 86, 87, 100};
		for (int t : time) {
			double population = calculatePopulation (p, k, r, t);
			System.out.println("The population at time t = " + t + " is: " + population);
		}
		

	}
}