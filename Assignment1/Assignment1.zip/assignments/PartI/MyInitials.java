import java.util.HashMap;
import java.util.Map;

public class MyInitials {
	public static void main(String[] args) {
		char[][] A = {{' ', ' ', 'A', ' ', ' '},
					  {' ', 'A', ' ', 'A', ' '},
					  {'A', ' ', ' ', ' ', 'A'},
					  {'A', 'A', 'A', 'A', 'A'},
					  {'A', ' ', ' ', ' ', 'A'},
					  {'A', ' ', ' ', ' ', 'A'},
					  {'A', ' ', ' ', ' ', 'A'}};
		
		char[][] R = {{'R', 'R', 'R', 'R', ' '},
					  {'R', ' ', ' ', ' ', 'R'},
					  {'R', ' ', ' ', ' ', 'R'},
					  {'R', 'R', 'R', 'R', 'R'},
					  {'R', ' ', 'R', ' ', ' '},
					  {'R', ' ', ' ', 'R', ' '},
					  {'R', ' ', ' ', ' ', 'R'}};
		
		char[][][] initials = {A, R, A};
        
        for (int row = 0; row < 7; row++) { 
        	StringBuilder line = new StringBuilder();
            for (char[][] str : initials) {
            	for (int col = 0; col < 5; col++) {
            		System.out.print(str[row][col]);
            	}
                System.out.print("   ");
            }
            System.out.println();
        }
    }
}
